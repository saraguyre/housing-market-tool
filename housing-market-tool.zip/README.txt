# Netlify deployment package

This package fixes the HUD CORS issue and removes your API keys from the browser.

## Files
- index.html
- netlify/functions/hud.js
- netlify/functions/rentcast.js
- netlify.toml

## Set these Netlify environment variables
- HUD_TOKEN
- CENSUS_KEY
- RENTCAST_API_KEY

## Important
Your current RentCast key returned 401 in the browser. If it also returns 401 through the proxy, then the key or plan does not include the market/listing endpoints. The HUD side should work once the env vars are added.

## Deploy
Upload this folder to Netlify or connect it as a repo, then add the environment variables in Site configuration.
